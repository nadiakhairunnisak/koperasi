import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:intl/intl.dart';

class AccountingPage extends StatefulWidget {
  @override
  _AccountingPageState createState() => _AccountingPageState();
}

class _AccountingPageState extends State<AccountingPage> {
  List<Map<String, dynamic>> transactions = [];
  List<Map<String, dynamic>> filteredTransactions = [];
  bool isLoading = true;
  String? userId;
  DateTime? selectedDate;
  String activeTab = 'Jurnal Umum';
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadUserId();
  }

  Future<void> _loadUserId() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? id = pref.getString('id_user');
    if (id != null) {
      setState(() {
        userId = id;
      });
      _fetchTransactions(id);
    }
  }

  Future<void> _fetchTransactions(String userId) async {
    final url = Uri.parse('${dotenv.env['url']}/getbukuBesar');
    try {
      final response = await http.get(url);
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        setState(() {
          transactions = data.map((item) => {
            'tanggal': item['tanggal'],
            'nama_akun': item['nama_akun'],
            'debit': item['debit'],
            'kredit': item['kredit'],
            'deskripsi': item['deskripsi'],
            'saldo': item['saldo'] ?? 0,
          }).toList();
          filteredTransactions = transactions;
          isLoading = false;
        });
      }
    } catch (e) {
      print('Error fetching data: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF3F51B5),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Kembali', style: TextStyle(color: Colors.black)),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Tab Selection
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: _buildTab('Jurnal Umum'),
                ),
                Expanded(
                  child: _buildTab('Buku Besar'),
                ),
              ],
            ),
          ),

          // Filter Buttons
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: _buildFilterButton(
                    icon: Icons.calendar_today,
                    label: 'Pilih Tanggal',
                    onPressed: () => _selectDate(context),
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: _buildFilterButton(
                    icon: Icons.account_balance_wallet,
                    label: 'Pilih Akun',
                    onPressed: () {
                      // Implement account selection
                    },
                  ),
                ),
              ],
            ),
          ),

          // Search Bar
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white.withOpacity(0.7),
                hintText: 'Cari...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),

          // Title
          Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Column(
              children: [
                Text(
                  activeTab,
                  style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Text(
                  'Koperasi Konsumen Polibeng',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
                Text(
                  selectedDate != null 
                      ? DateFormat('MMMM yyyy').format(selectedDate!)
                      : 'Januari 2024',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ],
            ),
          ),

          // Content
          Expanded(
            child: Container(
              margin: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
              ),
              child: activeTab == 'Jurnal Umum' 
                  ? _buildJurnalUmumTable()
                  : _buildBukuBesarTable(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: Color(0xFF3F51B5),
        unselectedItemColor: Colors.grey,
        currentIndex: 0,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Beranda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        onTap: (index) {
          if (index == 0) {
            Navigator.pop(context);
          }
        },
      ),
    );
  }

  Widget _buildTab(String title) {
    bool isActive = activeTab == title;
    return GestureDetector(
      onTap: () {
        setState(() {
          activeTab = title;
        });
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isActive ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(25),
        ),
        child: Text(
          title,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: isActive ? Color(0xFF3F51B5) : Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _buildFilterButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return ElevatedButton.icon(
      icon: Icon(icon, color: Color(0xFF3F51B5)),
      label: Text(label, style: TextStyle(color: Color(0xFF3F51B5))),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25),
        ),
        padding: EdgeInsets.symmetric(vertical: 12),
      ),
      onPressed: onPressed,
    );
  }

  Widget _buildJurnalUmumTable() {
    if (isLoading) {
      return Center(child: CircularProgressIndicator());
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SingleChildScrollView(
        child: DataTable(
          columns: [
            DataColumn(label: Text('Transaksi')),
            DataColumn(label: Text('Debit')),
            DataColumn(label: Text('Kredit')),
          ],
          rows: filteredTransactions.map((transaction) {
            return DataRow(
              cells: [
                DataCell(Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(DateFormat('dd MMM yyyy').format(
                      DateFormat('yyyy-MM-dd').parse(transaction['tanggal'])
                    )),
                    Text(transaction['nama_akun']),
                  ],
                )),
                DataCell(Text(NumberFormat.currency(
                  locale: 'id',
                  symbol: 'Rp ',
                  decimalDigits: 0,
                ).format(transaction['debit']))),
                DataCell(Text(NumberFormat.currency(
                  locale: 'id',
                  symbol: 'Rp ',
                  decimalDigits: 0,
                ).format(transaction['kredit']))),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildBukuBesarTable() {
    if (isLoading) {
      return Center(child: CircularProgressIndicator());
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SingleChildScrollView(
        child: DataTable(
          columns: [
            DataColumn(label: Text('Tanggal')),
            DataColumn(label: Text('Transaksi')),
            DataColumn(label: Text('Debit')),
            DataColumn(label: Text('Kredit')),
            DataColumn(label: Text('Saldo')),
          ],
          rows: filteredTransactions.map((transaction) {
            return DataRow(
              cells: [
                DataCell(Text(DateFormat('dd MMM yyyy').format(
                  DateFormat('yyyy-MM-dd').parse(transaction['tanggal'])
                ))),
                DataCell(Text(transaction['nama_akun'])),
                DataCell(Text(NumberFormat.currency(
                  locale: 'id',
                  symbol: 'Rp ',
                  decimalDigits: 0,
                ).format(transaction['debit']))),
                DataCell(Text(NumberFormat.currency(
                  locale: 'id',
                  symbol: 'Rp ',
                  decimalDigits: 0,
                ).format(transaction['kredit']))),
                DataCell(Text(NumberFormat.currency(
                  locale: 'id',
                  symbol: 'Rp ',
                  decimalDigits: 0,
                ).format(transaction['saldo']))),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        _filterTransactions();
      });
    }
  }

  void _filterTransactions() {
    if (selectedDate == null) {
      setState(() {
        filteredTransactions = transactions;
      });
      return;
    }

    setState(() {
      filteredTransactions = transactions.where((transaction) {
        DateTime transactionDate = DateFormat('yyyy-MM-dd').parse(transaction['tanggal']);
        return transactionDate.year == selectedDate!.year &&
               transactionDate.month == selectedDate!.month;
      }).toList();
    });
  }
}