import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:intl/intl.dart';

class AccountingPage extends StatefulWidget {
  @override
  _AccountingPageState createState() => _AccountingPageState();
}

class _AccountingPageState extends State<AccountingPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<Map<String, dynamic>> transactions = [];
  List<Map<String, dynamic>> filteredTransactions = [];
  bool isLoading = true;
  String? userId;
  DateTime? selectedDate;
  String? selectedAccount;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadUserId();
  }

  Future<void> _loadUserId() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? id = pref.getString('id_user');
    if (id != null) {
      setState(() {
        userId = id;
      });
      _fetchTransactions(id);
    } else {
      print('User ID not found in SharedPreferences');
    }
  }

  Future<void> _fetchTransactions(String userId) async {
    final url = Uri.parse('${dotenv.env['url']}/getbukuBesar');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        setState(() {
          transactions = data.map((item) {
            return {
              'tanggal': item['tanggal'],
              'nama_akun': item['nama_akun'],
              'debit': item['debit'],
              'kredit': item['kredit'],
              'deskripsi': item['deskripsi'],
            };
          }).toList();

          filteredTransactions = transactions;
          isLoading = false;
        });
      } else {
        print('Failed to load data');
      }
    } catch (e) {
      print('Error fetching data: $e');
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        _filterTransactions();
      });
    }
  }

  void _filterTransactions() {
    if (selectedDate == null) {
      setState(() {
        filteredTransactions = transactions;
      });
      return;
    }

    setState(() {
      filteredTransactions = transactions.where((transaction) {
        DateTime transactionDate = DateFormat('yyyy-MM-dd').parse(transaction['tanggal']);
        return transactionDate.year == selectedDate!.year &&
               transactionDate.month == selectedDate!.month;
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF3F51B5),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Kembali', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: TabBar(
              controller: _tabController,
              indicator: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(25),
              ),
              labelColor: Color(0xFF3F51B5),
              unselectedLabelColor: Colors.white,
              tabs: [
                Tab(text: 'Jurnal Umum'),
                Tab(text: 'Buku Besar'),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.calendar_today, color: Color(0xFF3F51B5)),
                    label: Text(
                      selectedDate == null 
                          ? 'Pilih Tanggal'
                          : DateFormat('MMMM yyyy').format(selectedDate!),
                      style: TextStyle(color: Color(0xFF3F51B5)),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    onPressed: () => _selectDate(context),
                  ),
                ),
                SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    icon: Icon(Icons.account_balance_wallet, color: Color(0xFF3F51B5)),
                    label: Text('Pilih Akun', style: TextStyle(color: Color(0xFF3F51B5))),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    onPressed: () {
                      // Implement account selection
                    },
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text(
              'Koperasi Konsumen Polibeng\n${selectedDate != null ? DateFormat('MMMM yyyy').format(selectedDate!) : ""}',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildJurnalUmum(),
                _buildBukuBesar(),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: Color(0xFF3F51B5),
        unselectedItemColor: Colors.grey,
        currentIndex: 0,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Beranda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        onTap: (index) {
          if (index == 0) {
            Navigator.pop(context);
          }
          // Implement profile navigation for index 1
        },
      ),
    );
  }

  Widget _buildJurnalUmum() {
    if (isLoading) {
      return Center(child: CircularProgressIndicator(color: Colors.white));
    }

    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListView.builder(
        itemCount: filteredTransactions.length,
        itemBuilder: (context, index) {
          final transaction = filteredTransactions[index];
          return Container(
            margin: EdgeInsets.all(8),
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  DateFormat('dd MMM yyyy').format(
                    DateFormat('yyyy-MM-dd').parse(transaction['tanggal'])
                  ),
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 4),
                Text(transaction['deskripsi']),
                SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(transaction['nama_akun']),
                    Text(
                      'Rp. ${NumberFormat('#,###').format(transaction['debit'])}',
                      style: TextStyle(color: Colors.black),
                    ),
                  ],
                ),
                if (transaction['kredit'] > 0)
                  Padding(
                    padding: EdgeInsets.only(left: 20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(transaction['nama_akun']),
                        Text(
                          'Rp. ${NumberFormat('#,###').format(transaction['kredit'])}',
                          style: TextStyle(color: Colors.black),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildBukuBesar() {
    if (isLoading) {
      return Center(child: CircularProgressIndicator(color: Colors.white));
    }

    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: ListView.builder(
        itemCount: filteredTransactions.length,
        itemBuilder: (context, index) {
          final transaction = filteredTransactions[index];
          return Container(
            margin: EdgeInsets.all(8),
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.grey.shade200)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  transaction['nama_akun'],
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 4),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(DateFormat('dd MMM yyyy').format(
                      DateFormat('yyyy-MM-dd').parse(transaction['tanggal'])
                    )),
                    Row(
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text('Debit: Rp. ${NumberFormat('#,###').format(transaction['debit'])}'),
                            Text('Kredit: Rp. ${NumberFormat('#,###').format(transaction['kredit'])}'),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}