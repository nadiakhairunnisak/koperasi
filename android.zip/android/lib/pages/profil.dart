import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class ProfileScreen extends StatefulWidget {
  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, String> profileData = {
    'Nama': '',
    'ID Anggota': '',
    'Jabatan': '',
    'Anggota Aktif': '',
    'Pekerjaan': '',
    'Telepon': '',
    'Alamat': '',
    'image': '',
  };

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  Future<void> _loadProfileData() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    setState(() {
      profileData['Nama'] = pref.getString("full_name") ?? "N/A";
      profileData['ID Anggota'] = pref.getString("id_user") ?? "N/A";
      profileData['Jabatan'] = pref.getString("jabatan") ?? "N/A";
      profileData['Anggota Aktif'] =
          (pref.getString("is_active") == "Y") ? "Aktif" : "Tidak Aktif";
      profileData['Pekerjaan'] = pref.getString("pekerjaan") ?? "N/A";
      profileData['Telepon'] = pref.getString("tlp") ?? "N/A";
      profileData['Alamat'] = pref.getString("alamat") ?? "N/A";
      profileData['image'] = pref.getString("image") ?? "";
    });
  }

  @override
  Widget build(BuildContext context) {
    String imageUrl = profileData['image']!.isEmpty
        ? 'https://via.placeholder.com/150'
        : '${dotenv.env['urlImage']}/assets/foto/user/${profileData['image']}';

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Kembali',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: Stack(
        children: [
          // Background shape
          Container(
            height: MediaQuery.of(context).size.height * 0.3,
            decoration: BoxDecoration(
              color: Colors.grey[100],
            ),
          ),
          
          SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 20),
                // Profile Image with Camera Icon
                Stack(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.deepPurple[700],
                      child: CircleAvatar(
                        radius: 48,
                        backgroundImage: NetworkImage(imageUrl),
                      ),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        padding: EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.deepPurple[700],
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.camera_alt,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 30),
                
                // Profile Info Card
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                    color: Colors.deepPurple[700],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Column(
                      children: [
                        buildProfileRow('Nama', profileData['Nama']!),
                        buildDivider(),
                        buildProfileRow('ID Anggota', profileData['ID Anggota']!),
                        buildDivider(),
                        buildProfileRow('Jabatan', profileData['Jabatan']!),
                        buildDivider(),
                        buildProfileRow('Anggota Aktif', profileData['Anggota Aktif']!),
                        buildDivider(),
                        buildProfileRow('Pekerjaan', profileData['Pekerjaan']!),
                        buildDivider(),
                        buildProfileRow('Telepon', profileData['Telepon']!),
                        buildDivider(),
                        buildProfileRow('Alamat', profileData['Alamat']!),
                      ],
                    ),
                  ),
                ),
                
                SizedBox(height: 30),
                
                // Logout Button
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: ElevatedButton(
                    onPressed: () => _logout(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple[700],
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      minimumSize: Size(double.infinity, 45),
                    ),
                    child: Text(
                      'Keluar',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: 1,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Beranda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        onTap: (index) {
          if (index == 0) {
            Navigator.pushReplacementNamed(context, '/dashboard');
          }
        },
      ),
    );
  }

  Widget buildProfileRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
            ),
          ),
          SizedBox(width: 8),
          Text(
            ':',
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildDivider() {
    return Divider(
      color: Colors.white.withOpacity(0.2),
      height: 1,
    );
  }

  Future<void> _logout(BuildContext context) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    await pref.clear();
    Navigator.of(context).pushReplacementNamed('/login');
  }
}