import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

class SimpananScreen extends StatefulWidget {
  @override
  _SimpananScreenState createState() => _SimpananScreenState();
}

class _SimpananScreenState extends State<SimpananScreen> with SingleTickerProviderStateMixin {
  bool _isLoading = true;
  Map<String, dynamic> _data = {};
  TabController? _tabController;
  TextEditingController _searchController = TextEditingController();
  DateTime? _selectedDate;
  String? _selected;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    fetchData();
  }

  @override
  void dispose() {
    _tabController?.dispose();
    _searchController.dispose();
    super.dispose();
  }

  Future<void> fetchData() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? userId = pref.getString('id_user');
    if (userId == null) return;

    try {
      final response = await http.get(
        Uri.parse('${dotenv.env['url']}/detail_simpanan/$userId'),
      );

      if (response.statusCode == 200) {
        setState(() {
          _data = json.decode(response.body);
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat data: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F6F8),
        appBar: _buildAppBar(),
        body: _isLoading ? _buildLoading() : _buildBody(),
        bottomNavigationBar: _buildBottomNav(),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
  return AppBar(
    elevation: 0,
    backgroundColor: const Color(0xFF3949AB),
    leading: IconButton(
      icon: const Icon(Icons.arrow_back, color: Colors.white),
      onPressed: () => Navigator.pop(context),
    ),
    title: const Text( // Judul utama di tengah
      "Simpanan",
      style: TextStyle(color: Colors.white),
    ),
    centerTitle: true, // Membuat judul di tengah
    bottom: TabBar( // TabBar diletakkan di bawah AppBar
      controller: _tabController,
      tabs: const [
        Tab(text: "Simpanan"), // Teks lebih ringkas
        Tab(text: "Penarikan"), // Teks lebih ringkas
      ],
      indicatorColor: Colors.white,
      labelColor: Colors.white,
      unselectedLabelColor: Colors.grey[300],
    ),
  );
}

Widget _buildFilterSection() {
  return Padding( // Menambahkan padding di sekitar filter
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    child: Row(
      children: [
        Expanded(
          child: _buildFilterButton(
            'Tanggal', // Teks lebih ringkas
            () async {
              final date = await showDatePicker(
                context: context,
                initialDate: _selectedDate ?? DateTime.now(),
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
              );
              if (date != null) {
                setState(() => _selectedDate = date);
              }
            },
            icon: Icons.calendar_today,
          ),
        ),
        const SizedBox(width: 8), // Spasi lebih kecil
        Expanded(
          child: _buildFilterButton(
            'Jenis', // Teks lebih ringkas
            () {
              // TODO: Implement simpanan type picker
            },
            icon: Icons.filter_list, // Icon filter yang lebih umum
          ),
        ),
      ],
    ),
  );
}

  Widget _buildTabButton(String text, int index) {
    bool isSelected = _tabController?.index == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => _tabController?.animateTo(index),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 8, horizontal: 25),
          decoration: BoxDecoration(
            color: isSelected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            text,
            style: TextStyle(
              color: isSelected ? Color(0xFF3949AB) : Colors.white,
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }


  Widget _buildBody() {
    return TabBarView(
      controller: _tabController,
      children: [
        _buildSimpananTab(),
        _buildPenarikanTab(),
      ],
    );
  }

  Widget _buildSimpananTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          _buildFilterSection(),
          SizedBox(height: 16),
          _buildSimpananSection('Simpanan Pokok'),
          SizedBox(height: 16),
          _buildSimpananSection('Simpanan Wajib'),
          SizedBox(height: 16),
          _buildSimpananSection('Simpanan Sukarela'),
          SizedBox(height: 16),
          _buildTotalBalance('Total Saldo', _data['total_saldo'] ?? '0'),
        ],
      ),
    );
  }

  Widget _buildPenarikanTab() {
    final penarikanList = _data['penarikan'] ?? [];
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        children: [
          _buildFilterSection(),
          SizedBox(height: 16),
          ...penarikanList.map<Widget>((item) => _buildTransactionCard(
            item['title'],
            item['amount'],
            isWithdrawal: true,
          )).toList(),
          SizedBox(height: 16),
          _buildTotalBalance('Total Penarikan', _data['pengeluaran'] ?? '0'),
        ],
      ),
    );
  }

  Widget _buildFilter() {
    return Row(
      children: [
        Expanded(
          child: _buildFilterButton(
            'Pilih Tanggal',
            () async {
              final date = await showDatePicker(
                context: context,
                initialDate: _selectedDate ?? DateTime.now(),
                firstDate: DateTime(2020),
                lastDate: DateTime.now(),
              );
              if (date != null) {
                setState(() => _selectedDate = date);
              }
            },
            icon: Icons.calendar_today,
          ),
        ),
        SizedBox(width: 16),
        Expanded(
          child: _buildFilterButton(
            'Pilih Simpanan',
            () {
              // Show simpanan type picker
            },
            icon: Icons.account_balance_wallet,
          ),
        ),
      ],
    );
  }

  Widget _buildFilterButton(String text, VoidCallback onPressed, {IconData? icon}) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 18),
      label: Text(text),
      style: ElevatedButton.styleFrom(
        backgroundColor: Color(0xFF3949AB),
        foregroundColor: Colors.white,
        padding: EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
    );
  }

  Widget _buildSimpananSection(String title) {
    final transactions = (_data['rincian'] ?? []).where((item) =>
        item['title'].toString().contains(title)).toList();
    
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              title,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF3949AB),
              ),
            ),
          ),
          ...transactions.map((item) => _buildTransactionCard(
            item['title'],
            item['amount'],
          )),
          Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Saldo',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  'Rp ${_calculateSectionTotal(transactions)}',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF3949AB),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _calculateSectionTotal(List transactions) {
    // Replace this with actual calculation logic based on your data structure
    return transactions.fold<double>(
      0,
      (sum, item) => sum + double.parse(item['amount'].toString().replaceAll(RegExp(r'[^0-9]'), '')),
    ).toStringAsFixed(0);
  }

  Widget _buildTransactionCard(String title, String amount, {bool isWithdrawal = false}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Colors.grey.withOpacity(0.2)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title.split('|')[0].trim(),
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                if (title.contains('|'))
                  Text(
                    title.split('|')[1].trim(),
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey,
                    ),
                  ),
              ],
            ),
          ),
          Text(
            'Rp $amount',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: isWithdrawal ? Colors.red : Color(0xFF3949AB),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTotalBalance(String title, String amount) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Color(0xFF3949AB),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.account_balance_wallet, color: Colors.white),
          SizedBox(width: 12),
          Column(
            children: [
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
              Text(
                'Rp $amount',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNav() {
    return BottomAppBar(
      color: Colors.white,
      child: Container(
        height: 60,
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(Icons.home, 'Beranda', true),
            _buildNavItem(Icons.person, 'Profile', false),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isSelected) {
    return InkWell(
      onTap: () {
        if (label == 'Beranda') {
          Navigator.pop(context);
        }
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: isSelected ? Color(0xFF3949AB) : Colors.grey,
          ),
          Text(
            label,
            style: TextStyle(
              color: isSelected ? Color(0xFF3949AB) : Colors.grey,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoading() {
    return Center(
      child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF3949AB)),
      ),
    );
  }
}