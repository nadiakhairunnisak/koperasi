import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LaporanKeuangan extends StatefulWidget {
  @override
  _LaporanKeuanganState createState() => _LaporanKeuanganState();
}

class _LaporanKeuanganState extends State<LaporanKeuangan> {
  String selectedTab = 'Jurnal Umum';
  DateTime selectedDate = DateTime.now();

  Future<List<Map<String, dynamic>>> fetchJurnalUmum() async {
    final response = await http.get(Uri.parse('${dotenv.env['url']}/getbukuBesar'));
    if (response.statusCode == 200) {
      List<dynamic> jsonData = json.decode(response.body);
      return jsonData.map<Map<String, dynamic>>((item) => {
        'tanggal': item['tanggal'],
        'keterangan': item['keterangan'],
        'akun': item['deskripsi'],
        'debit': double.parse(item['debit'].toString()),
        'kredit': double.parse(item['kredit'].toString()),
      }).toList();
    } else {
      throw Exception('Failed to load data');
    }
  }

  Future<List<Map<String, dynamic>>> fetchBukuBesar() async {
    final response = await http.get(Uri.parse('${dotenv.env['url']}/getbukuBesar'));
    if (response.statusCode == 200) {
      List<dynamic> jsonData = json.decode(response.body);
      double saldo = 0;
      return jsonData.map<Map<String, dynamic>>((item) {
        double debit = double.parse(item['debit'].toString());
        double kredit = double.parse(item['kredit'].toString());
        saldo += debit - kredit;
        return {
          'tanggal': item['tanggal'],
          'transaksi': item['deskripsi'],
          'debit': debit,
          'kredit': kredit,
          'saldo': saldo,
        };
      }).toList();
    } else {
      throw Exception('Failed to load data');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF3949AB),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                    padding: EdgeInsets.zero,
                  ),
                  Text(
                    'Kembali',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                ],
              ),
            ),

            // Tab Selection
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Row(
                  children: [
                    _buildTab('Jurnal Umum'),
                    _buildTab('Buku Besar'),
                  ],
                ),
              ),
            ),

            // Date and Account Selection
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.calendar_today, color: Colors.white, size: 16),
                          SizedBox(width: 8),
                          Text(
                            'Pilih Tanggal',
                            style: TextStyle(color: Colors.white),
                          ),
                          Icon(Icons.arrow_drop_down, color: Colors.white),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(
                        children: [
                          Text(
                            'Pilih Akun',
                            style: TextStyle(color: Colors.white),
                          ),
                          Icon(Icons.arrow_drop_down, color: Colors.white),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Content
            Expanded(
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            selectedTab,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF3949AB),
                            ),
                          ),
                          Text(
                            'Koperasi Konsumen Polbeng',
                            style: TextStyle(color: Colors.grey),
                          ),
                          Text(
                            'Januari 2024',
                            style: TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: selectedTab == 'Jurnal Umum'
                          ? _buildJurnalUmum()
                          : _buildBukuBesar(),
                    ),
                  ],
                ),
              ),
            ),

            // Bottom Navigation
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: Colors.grey.shade200)),
              ),
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildNavItem(Icons.home, 'Beranda', true),
                  _buildNavItem(Icons.person_outline, 'Profile', false),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(String title) {
    bool isSelected = selectedTab == title;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => selectedTab = title),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? Color(0xFF3949AB) : Colors.white,
            borderRadius: BorderRadius.circular(25),
          ),
          child: Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isSelected ? Colors.white : Color(0xFF3949AB),
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isSelected) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: isSelected ? Color(0xFF3949AB) : Colors.grey,
        ),
        Text(
          label,
          style: TextStyle(
            color: isSelected ? Color(0xFF3949AB) : Colors.grey,
            fontSize: 12,
          ),
        ),
      ],
    );
  }

  Widget _buildJurnalUmum() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: fetchJurnalUmum(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(child: Text('No data available'));
        }

        return ListView.builder(
          padding: EdgeInsets.symmetric(horizontal: 16),
          itemCount: snapshot.data!.length,
          itemBuilder: (context, index) {
            final item = snapshot.data![index];
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item['tanggal'],
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(item['keterangan']),
                Padding(
                  padding: const EdgeInsets.only(left: 16.0),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: Text(item['akun']),
                      ),
                      Expanded(
                        child: Text(
                          'Rp ${item['debit'].toStringAsFixed(0)}',
                          textAlign: TextAlign.right,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Rp ${item['kredit'].toStringAsFixed(0)}',
                          textAlign: TextAlign.right,
                        ),
                      ),
                    ],
                  ),
                ),
                Divider(),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildBukuBesar() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: fetchBukuBesar(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return Center(child: Text('No data available'));
        }

        return Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  Expanded(flex: 2, child: Text('Tanggal/Transaksi')),
                  Expanded(child: Text('Debit', textAlign: TextAlign.right)),
                  Expanded(child: Text('Kredit', textAlign: TextAlign.right)),
                  Expanded(child: Text('Saldo', textAlign: TextAlign.right)),
                ],
              ),
            ),
            Divider(),
            // Content
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.symmetric(horizontal: 16),
                itemCount: snapshot.data!.length,
                itemBuilder: (context, index) {
                  final item = snapshot.data![index];
                  return Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item['tanggal']),
                                Text(item['transaksi']),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Text(
                              'Rp ${item['debit'].toStringAsFixed(0)}',
                              textAlign: TextAlign.right,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              'Rp ${item['kredit'].toStringAsFixed(0)}',
                              textAlign: TextAlign.right,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              'Rp ${item['saldo'].toStringAsFixed(0)}',
                              textAlign: TextAlign.right,
                            ),
                          ),
                        ],
                      ),
                      Divider(),
                    ],
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}