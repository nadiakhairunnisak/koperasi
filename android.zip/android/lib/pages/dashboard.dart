import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  bool _isLoading = true;
  Map<String, dynamic> _data = {};
  String? _profileImageUrl;
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    setState(() {
      _isLoading = true;
    });

    SharedPreferences pref = await SharedPreferences.getInstance();
    String? userId = pref.getString('id_user');
    String? profileImage = pref.getString('profile_image');

    if (userId == null) {
      print('User ID not found in SharedPreferences');
      setState(() {
        _isLoading = false;
      });
      return;
    }

    setState(() {
      _profileImageUrl = profileImage;
    });

    await fetchData(userId);
  }

  Future<void> fetchData(String userId) async {
    final url = Uri.parse('${dotenv.env['url']}/detail_simpanan/$userId');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        setState(() {
          _data = json.decode(response.body);
          _isLoading = false;
        });
      } else {
        setState(() {
          _isLoading = false;
        });
        print('Error: ${response.statusCode}');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      print('Failed to load data: $e');
    }
  }

  void _showSearchDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Pilih Menu'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(Icons.savings),
                title: Text('Simpanan'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/simpanan');
                },
              ),
              ListTile(
                leading: Icon(Icons.description),
                title: Text('Laporan'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/LaporanKeuangan');
                },
              ),
              ListTile(
                leading: Icon(Icons.account_balance),
                title: Text('accountingPage'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/AccountingPage');
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: RefreshIndicator(
        onRefresh: () => _loadUserData(),
        child: _isLoading
            ? Center(child: CircularProgressIndicator())
            : CustomScrollView(
                slivers: [
                  SliverAppBar(
                    floating: true,
                    backgroundColor: Colors.white,
                    elevation: 0,
                    title: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Nadia Khairunnisak',
                          style: TextStyle(color: Colors.black, fontSize: 16),
                        ),
                        Text(
                          'Anggota',
                          style: TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                      ],
                    ),
                    actions: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: CircleAvatar(
                          backgroundImage: _profileImageUrl != null
                              ? NetworkImage(_profileImageUrl!)
                              : AssetImage('assets/images/profile.jpg') as ImageProvider,
                        ),
                      ),
                    ],
                  ),
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Koperasi Konsumen Polbeng',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 20),
                          _buildSearchBar(),
                          SizedBox(height: 20),
                          _buildMainMenu(),
                          SizedBox(height: 20),
                          _buildFinancialReports(),
                          SizedBox(height: 20),
                          _buildTransactionSummary(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
      ),
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  Widget _buildSearchBar() {
    return InkWell(
      onTap: _showSearchDialog,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              spreadRadius: 1,
              blurRadius: 4,
              offset: Offset(0, 1),
            ),
          ],
        ),
        child: Row(
          children: [
            Icon(Icons.search, color: Colors.grey),
            SizedBox(width: 10),
            Text(
              'Cari menu...',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMainMenu() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Color(0xFF3F51B5),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildMainMenuItem(
            icon: Icons.savings,
            label: 'Simpanan',
            onTap: () => Navigator.pushNamed(context, '/simpanan'),
          ),
          _buildMainMenuItem(
            icon: Icons.description,
            label: 'Laporan',
            onTap: () => Navigator.pushNamed(context, '/LaporanKeuangan'),
          ),
          _buildMainMenuItem(
            icon: Icons.account_balance,
            label: 'Akuntansi',
            onTap: () => Navigator.pushNamed(context, '/accountingPage'),
          ),
        ],
      ),
    );
  }

  Widget _buildMainMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white, size: 24),
          SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(color: Colors.white, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildFinancialReports() {
    return Column(
      children: [
        _buildReportSection(
          'Laporan Neraca',
          [
            {'label': 'Asset', 'value': 'Rp. 3.000.000'},
            {'label': 'Kewajiban', 'value': 'Rp. 2.000.000'},
            {'label': 'Modal', 'value': 'Rp. 1.000.000'},
          ],
          onSeeAll: () => Navigator.pushNamed(context, '/LaporanKeuangan'),
        ),
        SizedBox(height: 16),
        _buildReportSection(
          'Laporan Laba Rugi',
          [
            {'label': 'Pendapatan', 'value': 'Rp. 3.000.000'},
            {'label': 'Beban', 'value': 'Rp. 2.000.000'},
          ],
          onSeeAll: () => Navigator.pushNamed(context, '/LabaRugi'),
        ),
      ],
    );
  }

  Widget _buildReportSection(
    String title,
    List<Map<String, String>> items, {
    required VoidCallback onSeeAll,
  }) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
              InkWell(
                onTap: onSeeAll,
                child: Row(
                  children: [
                    Text('Lihat Semua ', style: TextStyle(color: Color(0xFF3F51B5))),
                    Icon(Icons.arrow_forward, color: Color(0xFF3F51B5), size: 16),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          ...items.map((item) => Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(item['label']!),
                    Text(item['value']!),
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildTransactionSummary() {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Total Transaksi Anggota',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              InkWell(
                onTap: () => Navigator.pushNamed(context, '/simpanan'),
                child: Row(
                  children: [
                    Text('Lihat Semua ', style: TextStyle(color: Color(0xFF3F51B5))),
                    Icon(Icons.arrow_forward, color: Color(0xFF3F51B5), size: 16),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 11),
          Row(
            children: [
              Expanded(
                child: _buildTransactionCard(
                  'Simpanan Dana',
                  'Rp. 750.000',
                  color: Color(0xFF3F51B5),
                ),
              ),
              SizedBox(width: 11),
              Expanded(
                child: _buildTransactionCard(
                  'Penarikan Dana',
                  'Rp. 200.000',
                  color: Color(0xFF3F51B5),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionCard(String title, String amount, {required Color color}) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(color: Colors.white, fontSize: 12),
          ),
          SizedBox(height: 8),
          Text(
            amount,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavBar() {
    return BottomNavigationBar(
      currentIndex: 0,
      selectedItemColor: Color(0xFF3F51B5),
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.home),
          label: 'Beranda',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: 'Profile',
        ),
      ],
      onTap: (index) {
        if (index == 1) {
          Navigator.pushNamed(context, '/profil');
        }
      },
    );
  }
}